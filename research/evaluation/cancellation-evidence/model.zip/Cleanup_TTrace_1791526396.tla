---- MODULE Cleanup_TTrace_1791526396 ----
EXTENDS Sequences, TLCExt, Toolbox, Naturals, TLC, Cleanup, Cleanup_TEConstants

_expression ==
    LET Cleanup_TEExpression == INSTANCE Cleanup_TEExpression
    IN Cleanup_TEExpression!expression
----

_trace ==
    LET Cleanup_TETrace == INSTANCE Cleanup_TETrace
    IN Cleanup_TETrace!trace
----

_prop ==
    ~<>[](
        phase = ((c1 :> "cancelling"))
        /\
        callerCancelled = (FALSE)
        /\
        verdict = ((c1 :> "escalate"))
        /\
        closed = (TRUE)
        /\
        resolutions = ((c1 :> 1))
        /\
        first = ((c1 :> "denied"))
        /\
        outcome = ("none")
        /\
        status = ((c1 :> "denied"))
        /\
        evaluator = ((c1 :> "cancelling"))
    )
----

_init ==
    /\ verdict = _TETrace[1].verdict
    /\ first = _TETrace[1].first
    /\ closed = _TETrace[1].closed
    /\ outcome = _TETrace[1].outcome
    /\ status = _TETrace[1].status
    /\ phase = _TETrace[1].phase
    /\ evaluator = _TETrace[1].evaluator
    /\ resolutions = _TETrace[1].resolutions
    /\ callerCancelled = _TETrace[1].callerCancelled
----

_next ==
    /\ \E i,j \in DOMAIN _TETrace:
        /\ \/ /\ j = i + 1
              /\ i = TLCGet("level")
        /\ verdict  = _TETrace[i].verdict
        /\ verdict' = _TETrace[j].verdict
        /\ first  = _TETrace[i].first
        /\ first' = _TETrace[j].first
        /\ closed  = _TETrace[i].closed
        /\ closed' = _TETrace[j].closed
        /\ outcome  = _TETrace[i].outcome
        /\ outcome' = _TETrace[j].outcome
        /\ status  = _TETrace[i].status
        /\ status' = _TETrace[j].status
        /\ phase  = _TETrace[i].phase
        /\ phase' = _TETrace[j].phase
        /\ evaluator  = _TETrace[i].evaluator
        /\ evaluator' = _TETrace[j].evaluator
        /\ resolutions  = _TETrace[i].resolutions
        /\ resolutions' = _TETrace[j].resolutions
        /\ callerCancelled  = _TETrace[i].callerCancelled
        /\ callerCancelled' = _TETrace[j].callerCancelled

\* Uncomment the ASSUME below to write the states of the error trace
\* to the given file in Json format. Note that you can pass any tuple
\* to `JsonSerialize`. For example, a sub-sequence of _TETrace.
    \* ASSUME
    \*     LET J == INSTANCE Json
    \*         IN J!JsonSerialize("Cleanup_TTrace_1791526396.json", _TETrace)

=============================================================================

 Note that you can extract this module `Cleanup_TEExpression`
  to a dedicated file to reuse `expression` (the module in the 
  dedicated `Cleanup_TEExpression.tla` file takes precedence 
  over the module `Cleanup_TEExpression` below).

---- MODULE Cleanup_TEExpression ----
EXTENDS Sequences, TLCExt, Toolbox, Naturals, TLC, Cleanup, Cleanup_TEConstants

expression == 
    [
        \* To hide variables of the `Cleanup` spec from the error trace,
        \* remove the variables below.  The trace will be written in the order
        \* of the fields of this record.
        verdict |-> verdict
        ,first |-> first
        ,closed |-> closed
        ,outcome |-> outcome
        ,status |-> status
        ,phase |-> phase
        ,evaluator |-> evaluator
        ,resolutions |-> resolutions
        ,callerCancelled |-> callerCancelled
        
        \* Put additional constant-, state-, and action-level expressions here:
        \* ,_stateNumber |-> _TEPosition
        \* ,_verdictUnchanged |-> verdict = verdict'
        
        \* Format the `verdict` variable as Json value.
        \* ,_verdictJson |->
        \*     LET J == INSTANCE Json
        \*     IN J!ToJson(verdict)
        
        \* Lastly, you may build expressions over arbitrary sets of states by
        \* leveraging the _TETrace operator.  For example, this is how to
        \* count the number of times a spec variable changed up to the current
        \* state in the trace.
        \* ,_verdictModCount |->
        \*     LET F[s \in DOMAIN _TETrace] ==
        \*         IF s = 1 THEN 0
        \*         ELSE IF _TETrace[s].verdict # _TETrace[s-1].verdict
        \*             THEN 1 + F[s-1] ELSE F[s-1]
        \*     IN F[_TEPosition - 1]
    ]

=============================================================================



Parsing and semantic processing can take forever if the trace below is long.
 In this case, it is advised to uncomment the module below to deserialize the
 trace from a generated binary file.

\*
\*---- MODULE Cleanup_TETrace ----
\*EXTENDS IOUtils, TLC, Cleanup, Cleanup_TEConstants
\*
\*trace == IODeserialize("Cleanup_TTrace_1791526396.bin", TRUE)
\*
\*=============================================================================
\*

---- MODULE Cleanup_TETrace ----
EXTENDS TLC, Cleanup, Cleanup_TEConstants

trace == 
    <<
    ([phase |-> (c1 :> "evaluating"),callerCancelled |-> FALSE,verdict |-> (c1 :> "none"),closed |-> FALSE,resolutions |-> (c1 :> 0),first |-> (c1 :> "none"),outcome |-> "none",status |-> (c1 :> "pending"),evaluator |-> (c1 :> "running")]),
    ([phase |-> (c1 :> "evaluating"),callerCancelled |-> FALSE,verdict |-> (c1 :> "none"),closed |-> TRUE,resolutions |-> (c1 :> 0),first |-> (c1 :> "none"),outcome |-> "none",status |-> (c1 :> "pending"),evaluator |-> (c1 :> "running")]),
    ([phase |-> (c1 :> "evaluating"),callerCancelled |-> FALSE,verdict |-> (c1 :> "none"),closed |-> TRUE,resolutions |-> (c1 :> 1),first |-> (c1 :> "denied"),outcome |-> "none",status |-> (c1 :> "denied"),evaluator |-> (c1 :> "running")]),
    ([phase |-> (c1 :> "evaluating"),callerCancelled |-> FALSE,verdict |-> (c1 :> "escalate"),closed |-> TRUE,resolutions |-> (c1 :> 1),first |-> (c1 :> "denied"),outcome |-> "none",status |-> (c1 :> "denied"),evaluator |-> (c1 :> "done")]),
    ([phase |-> (c1 :> "cancelling"),callerCancelled |-> FALSE,verdict |-> (c1 :> "escalate"),closed |-> TRUE,resolutions |-> (c1 :> 1),first |-> (c1 :> "denied"),outcome |-> "none",status |-> (c1 :> "denied"),evaluator |-> (c1 :> "cancelling")])
    >>
----


=============================================================================

---- MODULE Cleanup_TEConstants ----
EXTENDS Cleanup

CONSTANTS c1

=============================================================================

---- CONFIG Cleanup_TTrace_1791526396 ----
CONSTANTS
    Calls = { c1 }
    AllowOverwrite = FALSE
    BypassGate = FALSE
    CleanupCanFinish = FALSE
    SwallowCallerCancel = TRUE
    c1 = c1

PROPERTY
    _prop

CHECK_DEADLOCK
    \* CHECK_DEADLOCK off because of PROPERTY or INVARIANT above.
    FALSE

INIT
    _init

NEXT
    _next

CONSTANT
    _TETrace <- _trace

ALIAS
    _expression
=============================================================================
\* Generated on Fri Oct 09 06:13:17 UTC 2026